package com.gifgrabber.app;

import android.graphics.Bitmap;
import java.io.*;
import java.util.*;

/** Small, dependency-free, animated GIF89a encoder. Uses fixed 3-3-2 RGB palette. */
public final class GifEncoder implements Closeable {
    private final OutputStream out;
    private final int width,height;
    private boolean closed;
    private int frames;
    public GifEncoder(OutputStream output,int w,int h) throws IOException {
        if(w<1||h<1||w>1024||h>1024)throw new IOException("Invalid GIF dimensions");
        out=output;width=w;height=h;
        out.write("GIF89a".getBytes("US-ASCII"));
        word(w);word(h);out.write(0xF7);out.write(0);out.write(0);
        for(int i=0;i<256;i++) {out.write(((i>>5)&7)*255/7);out.write(((i>>2)&7)*255/7);out.write((i&3)*255/3);}
        out.write(new byte[]{0x21,(byte)0xFF,11});out.write("NETSCAPE2.0".getBytes("US-ASCII"));
        out.write(new byte[]{3,1,0,0,0});
    }
    private void word(int n)throws IOException{out.write(n&255);out.write((n>>8)&255);}
    public void frame(Bitmap bitmap,int delayMs)throws IOException{
        if(closed)throw new IOException("GIF already closed");
        Bitmap b=bitmap;
        if(b.getWidth()!=width||b.getHeight()!=height)b=Bitmap.createScaledBitmap(bitmap,width,height,true);
        int[] pixels=new int[width*height];b.getPixels(pixels,0,width,0,0,width,height);
        byte[] indexes=new byte[pixels.length];
        for(int i=0;i<pixels.length;i++){int p=pixels[i];int a=(p>>>24)&255;int r=(p>>>16)&255,g=(p>>>8)&255,bl=p&255;
            if(a<255){r=(r*a+255*(255-a))/255;g=(g*a+255*(255-a))/255;bl=(bl*a+255*(255-a))/255;}
            indexes[i]=(byte)(((r>>5)<<5)|((g>>5)<<2)|(bl>>6));}
        if(b!=bitmap)b.recycle();
        out.write(new byte[]{0x21,(byte)0xF9,4,0});word(Math.max(2,delayMs/10));out.write(0);out.write(0);
        out.write(0x2C);word(0);word(0);word(width);word(height);out.write(0);
        out.write(8);writeLzw(indexes);frames++;
    }
    private void writeLzw(byte[] indexes)throws IOException{
        final int clear=256,end=257;int codeSize=9,next=258,limit=1<<codeSize;
        Map<Integer,Integer> dict=new HashMap<>();ByteArrayOutputStream packed=new ByteArrayOutputStream();
        long bits=0;int bitCount=0;
        // bit writer inline via helper to ensure bit widths change exactly on boundaries
        BitWriter bw=new BitWriter(packed);
        bw.write(clear,codeSize);
        int prefix=indexes[0]&255;
        for(int i=1;i<indexes.length;i++){
            int k=indexes[i]&255,key=(prefix<<8)|k;
            Integer code=dict.get(key);
            if(code!=null){prefix=code;continue;}
            bw.write(prefix,codeSize);
            if(next<4096){dict.put(key,next++);if(next>limit&&codeSize<12){codeSize++;limit=1<<codeSize;}}
            else{bw.write(clear,codeSize);dict.clear();codeSize=9;next=258;limit=512;}
            prefix=k;
        }
        bw.write(prefix,codeSize);bw.write(end,codeSize);bw.flush();
        byte[] data=packed.toByteArray();for(int pos=0;pos<data.length;pos+=255){int n=Math.min(255,data.length-pos);out.write(n);out.write(data,pos,n);}out.write(0);
    }
    private static class BitWriter{
        final OutputStream out;long value=0;int count=0;
        BitWriter(OutputStream o){out=o;}
        void write(int code,int size)throws IOException{value|=((long)code)<<count;count+=size;while(count>=8){out.write((int)(value&255));value>>>=8;count-=8;}}
        void flush()throws IOException{if(count>0)out.write((int)(value&255));}
    }
    @Override public void close()throws IOException{if(!closed){out.write(0x3B);out.flush();closed=true;}}
    public int frameCount(){return frames;}
}
