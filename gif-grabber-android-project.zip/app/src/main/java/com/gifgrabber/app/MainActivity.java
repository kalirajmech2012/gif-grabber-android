package com.gifgrabber.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.content.ContentValues;
import android.os.SystemClock;
import java.nio.file.Files;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout browserFrame;
    private final ArrayList<WebView> tabs=new ArrayList<>();
    private TextView tabsButton;
    private LinearLayout rootLayout;
    private boolean showingTabs=false;
    private EditText address;
    private LinearLayout selectionBar;
    private LinearLayout clipboardBar;
    private ClipboardManager clipboard;
    private TextView selectionCount;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final AtomicInteger filenameSequence = new AtomicInteger();
    private final String home = "https://www.google.com/search?tbm=isch&q=animated+gifs";
    private int count = 0;
    private int px(float dp) { return (int)(getResources().getDisplayMetrics().density*dp+0.5f); }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(px(radius));return d; }
    private TextView button(String label, Runnable action) {
        TextView b=new TextView(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setGravity(Gravity.CENTER);b.setPadding(px(12),px(12),px(12),px(12));b.setBackground(bg(0xff2463d3,12));b.setOnClickListener(v->action.run());return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        LinearLayout root=new LinearLayout(this);rootLayout=root;root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);setContentView(root);
        // Android 15+ edge-to-edge: keep toolbar BELOW the system status bar.
        root.setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
            v.setPadding(0,bars.top,0,bars.bottom);
            return insets;
        });
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);nav.setPadding(px(5),px(5),px(5),px(5));nav.setBackgroundColor(0xfff3f5f8);root.addView(nav,new LinearLayout.LayoutParams(-1,px(55)));
        TextView back=new TextView(this);back.setText("‹");back.setTextSize(32);back.setGravity(Gravity.CENTER);nav.addView(back,new LinearLayout.LayoutParams(px(39),-1));back.setOnClickListener(v->{if(web.canGoBack())web.goBack();});
        address=new EditText(this);address.setSingleLine(true);address.setTextSize(14);address.setSelectAllOnFocus(true);address.setPadding(px(13),0,px(13),0);address.setBackground(bg(Color.WHITE,22));address.setImeOptions(2);nav.addView(address,new LinearLayout.LayoutParams(0,px(42),1));
        address.setOnFocusChangeListener((v,hasFocus)->{if(hasFocus){address.selectAll();}});
        address.setOnEditorActionListener((v,id,event)->{go(address.getText().toString());return true;});
        tabsButton=new TextView(this);tabsButton.setText("1");tabsButton.setTextSize(17);tabsButton.setTextColor(0xff263b5a);tabsButton.setGravity(Gravity.CENTER);tabsButton.setBackground(bg(0xffdce5f3,8));LinearLayout.LayoutParams tbp=new LinearLayout.LayoutParams(px(37),px(37));tbp.setMargins(px(4),0,px(4),0);nav.addView(tabsButton,tbp);tabsButton.setOnClickListener(v->showTabs());
        TextView go=new TextView(this);go.setText("➜");go.setTextSize(23);go.setGravity(Gravity.CENTER);nav.addView(go,new LinearLayout.LayoutParams(px(43),-1));go.setOnClickListener(v->go(address.getText().toString()));
        // Clipboard suggestion is shown only if clipboard contains something; contents are read on tap.
        clipboardBar=new LinearLayout(this);clipboardBar.setGravity(Gravity.CENTER_VERTICAL);
        clipboardBar.setPadding(px(12),px(6),px(12),px(6));clipboardBar.setBackgroundColor(0xffeaf2ff);
        TextView hint=new TextView(this);hint.setText("Copied a link?  Paste & Open");hint.setTextColor(0xff164b9b);hint.setTextSize(14);
        clipboardBar.addView(hint,new LinearLayout.LayoutParams(0,px(40),1));
        hint.setOnClickListener(v->pasteAndOpen());
        TextView paste=button("Paste & Open",()->pasteAndOpen());clipboardBar.addView(paste);
        TextView dismiss=new TextView(this);dismiss.setText("  ✕  ");dismiss.setTextSize(22);dismiss.setGravity(Gravity.CENTER);
        clipboardBar.addView(dismiss);dismiss.setOnClickListener(v->clipboardBar.setVisibility(View.GONE));
        clipboardBar.setVisibility(View.GONE);root.addView(clipboardBar,new LinearLayout.LayoutParams(-1,px(56)));
        browserFrame=new FrameLayout(this);root.addView(browserFrame,new LinearLayout.LayoutParams(-1,0,1));
        createTab(home);
        selectionBar=new LinearLayout(this);selectionBar.setGravity(Gravity.CENTER_VERTICAL);selectionBar.setPadding(px(8),px(7),px(8),px(7));selectionBar.setBackgroundColor(0xffe9f0ff);selectionBar.setVisibility(View.GONE);root.addView(selectionBar,new LinearLayout.LayoutParams(-1,px(64)));
        selectionCount=new TextView(this);selectionCount.setTextColor(0xff1d376c);selectionCount.setTypeface(null,Typeface.BOLD);selectionCount.setTextSize(14);selectionBar.addView(selectionCount,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=button("Select All",()->web.evaluateJavascript("window.__gg&&__gg.all()",null));selectionBar.addView(all);
        TextView dl=button("Download",()->web.evaluateJavascript("window.__gg&&__gg.download()",null));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=px(6);selectionBar.addView(dl,p);
        TextView close=button("✕",()->web.evaluateJavascript("window.__gg&&__gg.clear()",null));p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=px(6);selectionBar.addView(close,p);
    }
    private void configureWebView(WebView w){
        w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);
        w.getSettings().setBuiltInZoomControls(true);w.getSettings().setDisplayZoomControls(false);
        w.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        w.addJavascriptInterface(new Bridge(w),"GifGrabberNative");
        w.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onCreateWindow(WebView view,boolean dialog,boolean userGesture,android.os.Message resultMsg){
                if(!userGesture)return false;
                WebView child=createTab("about:blank");
                WebView.WebViewTransport transport=(WebView.WebViewTransport)resultMsg.obj;
                transport.setWebView(child);resultMsg.sendToTarget();return true;
            }
        });
        w.getSettings().setSupportMultipleWindows(true);
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){
                if(v==web){address.setText(url);resetSelection();}
                v.evaluateJavascript(script(),null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                return !"http".equals(r.getUrl().getScheme())&&!"https".equals(r.getUrl().getScheme());
            }
        });
    }
    private WebView createTab(String url){
        WebView w=new WebView(this);configureWebView(w);
        tabs.add(w);activateTab(w);
        if(!"about:blank".equals(url))w.loadUrl(url);
        return w;
    }
    private void activateTab(WebView w){
        web=w;showingTabs=false;browserFrame.removeAllViews();
        if(w.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)w.getParent()).removeView(w);
        browserFrame.addView(w,new FrameLayout.LayoutParams(-1,-1));
        if(address!=null)address.setText(w.getUrl()==null?"":w.getUrl());
        if(tabsButton!=null)tabsButton.setText(String.valueOf(tabs.size()));
        if(selectionBar!=null)resetSelection();
    }
    private void showTabs(){
        if(showingTabs)return;
        showingTabs=true;browserFrame.removeAllViews();
        ScrollView scroll=new ScrollView(this);
        LinearLayout items=new LinearLayout(this);items.setOrientation(LinearLayout.VERTICAL);
        items.setPadding(px(12),px(12),px(12),px(12));
        TextView add=button("+ New Tab",()->createTab(home));
        items.addView(add,new LinearLayout.LayoutParams(-1,px(52)));
        for(WebView w:new ArrayList<>(tabs)){
            LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(px(10),px(9),px(8),px(9));
            String title=w.getTitle();
            if(title==null||title.trim().isEmpty())title=w.getUrl();
            if(title==null||title.trim().isEmpty())title="New Tab";
            TextView name=new TextView(this);name.setText(title);name.setTextSize(15);
            name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            line.addView(name,new LinearLayout.LayoutParams(0,px(54),1));
            name.setOnClickListener(v->activateTab(w));
            TextView close=button("X",()->closeTab(w));
            line.addView(close,new LinearLayout.LayoutParams(px(52),px(48)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,px(72));lp.bottomMargin=px(7);
            line.setBackground(bg(0xffeef2f8,12));items.addView(line,lp);
        }
        scroll.addView(items);browserFrame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        tabsButton.setText(String.valueOf(tabs.size()));
    }
    private void closeTab(WebView w){
        tabs.remove(w);
        if(w.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)w.getParent()).removeView(w);
        w.stopLoading();w.destroy();
        if(tabs.isEmpty())createTab(home);
        else if(web==w)activateTab(tabs.get(tabs.size()-1));
        else {showingTabs=false;showTabs();}
    }
    @Override protected void onResume(){super.onResume();if(clipboardBar!=null){
        boolean has=false;try{has=clipboard!=null&&clipboard.hasPrimaryClip();}catch(Exception ignored){}
        clipboardBar.setVisibility(has?View.VISIBLE:View.GONE);
    }}
    private void pasteAndOpen(){
        try{
            ClipData data=clipboard==null?null:clipboard.getPrimaryClip();
            if(data==null||data.getItemCount()==0)return;
            CharSequence cs=data.getItemAt(0).coerceToText(this);
            String value=cs==null?"":cs.toString().trim();
            if(value.matches("(?i)^https?://\\S+$")){
                address.setText(value);clipboardBar.setVisibility(View.GONE);go(value);
            }else{Toast.makeText(this,"Clipboard does not contain a web link",Toast.LENGTH_SHORT).show();}
        }catch(Exception e){Toast.makeText(this,"Cannot read clipboard",Toast.LENGTH_SHORT).show();}
    }
    private void go(String raw){String u=raw.trim();if(u.isEmpty())return;if(!u.matches("(?i)^https?://.*")){if(u.contains(".")&&!u.contains(" "))u="https://"+u;else u="https://www.google.com/search?q="+Uri.encode(u);}web.loadUrl(u);address.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);}
    private void resetSelection(){count=0;selectionBar.setVisibility(View.GONE);}
    @Override public void onBackPressed(){if(showingTabs){activateTab(web);}else if(count>0){web.evaluateJavascript("window.__gg&&__gg.clear()",null);}else if(web.canGoBack())web.goBack();else super.onBackPressed();}
    private class Bridge {
        private final WebView owner;
        Bridge(WebView w){owner=w;}
        @JavascriptInterface public void selection(int n){runOnUiThread(()->{if(owner!=web)return;count=n;selectionCount.setText(n+" selected");selectionBar.setVisibility(n>0?View.VISIBLE:View.GONE);});}
        @JavascriptInterface public void download(String json){try{JSONArray a=new JSONArray(json);LinkedHashSet<String> urls=new LinkedHashSet<>();for(int i=0;i<a.length();i++){String u=a.optString(i,"");if(u.startsWith("https://")||u.startsWith("http://"))urls.add(u);}runOnUiThread(()->{
            if(urls.isEmpty())return;
            // WebView and CookieManager must be accessed on the UI thread.
            final String userAgent=owner.getSettings().getUserAgentString();
            final String referer=owner.getUrl();
            Toast.makeText(MainActivity.this,"Checking "+urls.size()+" image(s)",Toast.LENGTH_SHORT).show();
            for(String u:urls){
                String cookies=android.webkit.CookieManager.getInstance().getCookie(u);
                pool.execute(()->saveGif(u,userAgent,referer,cookies));
            }
        });}catch(Exception ignored){}}
    }
    private void saveGif(String link,String userAgent,String referer,String cookies){
        HttpURLConnection c=null;Uri pending=null;
        try{
            URL url=new URL(link);
            if(!url.getProtocol().equals("https")&&!url.getProtocol().equals("http"))return;
            c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent",userAgent);
            c.setRequestProperty("Accept","image/gif,image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
            if(referer!=null&&referer.startsWith("http"))c.setRequestProperty("Referer",referer);
            if(cookies!=null)c.setRequestProperty("Cookie",cookies);
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            // Download the actual media bytes first. Never rename a WebP/video as GIF.
            File tmp=File.createTempFile("gg_media_",".bin",getCacheDir());
            try{
                try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream os=new FileOutputStream(tmp)){
                    byte[] buf=new byte[16384];int n;long total=0;
                    while((n=in.read(buf))!=-1){total+=n;if(total>80L*1024*1024)throw new IOException("Media larger than 80 MB");os.write(buf,0,n);}
                }
                byte[] head=new byte[32];int read;
                try(InputStream input=new FileInputStream(tmp)){read=input.read(head);}
                if(read<12)throw new IOException("Empty or unsupported media");
                String ascii=new String(head,0,read,java.nio.charset.StandardCharsets.ISO_8859_1);
                boolean gif=ascii.startsWith("GIF87a")||ascii.startsWith("GIF89a");
                boolean webp=ascii.startsWith("RIFF")&&ascii.substring(8,12).equals("WEBP");
                boolean png=(head[0]&255)==137&&ascii.substring(1,4).equals("PNG");
                boolean jpg=(head[0]&255)==255&&(head[1]&255)==216;
                boolean mp4=ascii.substring(4,8).equals("ftyp");
                boolean webm=ascii.startsWith("\u001aE\u00df\u00a3");
                String name="gif_grabber_"+System.currentTimeMillis()+"_"+filenameSequence.incrementAndGet();
                if(gif){pending=storeFile(tmp,name+".gif","image/gif");notice("Original GIF saved");}
                else if(webp){
                    if(Build.VERSION.SDK_INT<28)throw new IOException("Animated WebP conversion requires Android 9+");
                    File converted=File.createTempFile("gg_converted_",".gif",getCacheDir());
                    try{
                        int frames=convertAnimatedWebp(tmp,converted);
                        if(frames<2)throw new IOException("This WebP is a static thumbnail. Open the original media page.");
                        pending=storeFile(converted,name+".gif","image/gif");notice("Animated WebP converted to GIF ("+frames+" frames)");
                    }finally{converted.delete();}
                }
                else if(mp4||webm){
                    File converted=File.createTempFile("gg_converted_",".gif",getCacheDir());
                    try{
                        int frames=convertVideo(tmp,converted);
                        if(frames<2)throw new IOException("Video has too few decodable frames");
                        pending=storeFile(converted,name+".gif","image/gif");notice("Video converted to GIF ("+frames+" frames)");
                    }finally{converted.delete();}
                }
                else if(png||jpg)throw new IOException("Static thumbnail only. Open original animated media to download GIF.");
                else throw new IOException("Unsupported media format or site-specific stream");
            }finally{tmp.delete();}
        }catch(Exception e){if(pending!=null&&Build.VERSION.SDK_INT>=29)getContentResolver().delete(pending,null,null);
            runOnUiThread(()->Toast.makeText(this,"Download failed: "+e.getMessage(),Toast.LENGTH_SHORT).show());}
        finally{if(c!=null)c.disconnect();}
    }
    private void notice(String message){runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
    private Uri storeFile(File source,String name,String mime)throws IOException{
        Uri target=null;
        if(Build.VERSION.SDK_INT>=29){
            ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/GIFGrabber");v.put(MediaStore.Downloads.IS_PENDING,1);
            target=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(target==null)throw new IOException("Cannot create media download");
            try(OutputStream os=getContentResolver().openOutputStream(target);InputStream in=new FileInputStream(source)){
                if(os==null)throw new IOException("Cannot open download");byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)os.write(buf,0,n);
            }catch(Exception e){getContentResolver().delete(target,null,null);throw new IOException(e);}
            ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(target,done,null,null);
        }else{
            File dir=new File(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS),"GIFGrabber");
            if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create downloads folder");
            try(InputStream in=new FileInputStream(source);OutputStream os=new FileOutputStream(new File(dir,name))){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)os.write(buf,0,n);}
        }
        return target;
    }
    private int convertVideo(File media,File dest)throws IOException{
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try{
            retriever.setDataSource(media.getAbsolutePath());
            long duration=0;String durationString=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(durationString!=null)duration=Long.parseLong(durationString);
            duration=Math.min(duration,6000);if(duration<200)throw new IOException("Video duration unavailable");
            Bitmap first=retriever.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if(first==null)throw new IOException("Cannot decode video frames");
            int w=first.getWidth(),h=first.getHeight();double scale=Math.min(1.0,480.0/Math.max(w,h));w=Math.max(1,(int)(w*scale));h=Math.max(1,(int)(h*scale));first.recycle();
            int count=0;
            try(OutputStream os=new FileOutputStream(dest);GifEncoder encoder=new GifEncoder(os,w,h)){
                for(long ms=0;ms<duration&&count<48;ms+=125){
                    Bitmap frame=retriever.getFrameAtTime(ms*1000,MediaMetadataRetriever.OPTION_CLOSEST);
                    if(frame==null)continue;encoder.frame(frame,125);frame.recycle();count++;
                }
            }
            return count;
        }catch(RuntimeException e){throw new IOException("Video conversion failed: "+e.getMessage(),e);}
        finally{retriever.release();}
    }
    private int convertAnimatedWebp(File media,File dest)throws Exception{
        // ImageDecoder and AnimatedImageDrawable are Android 9+ APIs.
        CountDownLatch done=new CountDownLatch(1);
        final int[] count={0};final String[] error={null};
        runOnUiThread(()->{
            try{
                Drawable drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(media));
                if(!(drawable instanceof AnimatedImageDrawable)){error[0]="Static WebP thumbnail";done.countDown();return;}
                AnimatedImageDrawable anim=(AnimatedImageDrawable)drawable;
                int w=anim.getIntrinsicWidth(),h=anim.getIntrinsicHeight();
                if(w<=0||h<=0){error[0]="Invalid animated WebP dimensions";done.countDown();return;}
                double scale=Math.min(1.0,480.0/Math.max(w,h));w=Math.max(1,(int)(w*scale));h=Math.max(1,(int)(h*scale));
                final int fw=w,fh=h;final GifEncoder encoder=new GifEncoder(new FileOutputStream(dest),w,h);
                final Handler handler=new Handler(Looper.getMainLooper());
                final long started=SystemClock.uptimeMillis();
                anim.setBounds(0,0,w,h);anim.setRepeatCount(0);
                final Runnable[] sample=new Runnable[1];
                sample[0]=()->{
                    try{
                        if(SystemClock.uptimeMillis()-started>=6000||count[0]>=48){anim.stop();encoder.close();done.countDown();return;}
                        Bitmap frame=Bitmap.createBitmap(fw,fh,Bitmap.Config.ARGB_8888);
                        Canvas canvas=new Canvas(frame);canvas.drawColor(Color.WHITE);anim.draw(canvas);
                        encoder.frame(frame,125);frame.recycle();count[0]++;
                        handler.postDelayed(sample[0],125);
                    }catch(Exception e){error[0]=e.getMessage();anim.stop();try{encoder.close();}catch(Exception ignored){}done.countDown();}
                };
                anim.start();handler.post(sample[0]);
            }catch(Exception e){error[0]=e.getMessage();done.countDown();}
        });
        if(!done.await(12,TimeUnit.SECONDS))throw new IOException("WebP conversion timed out");
        if(error[0]!=null)throw new IOException(error[0]);
        return count[0];
    }
    private String script(){return "(function(){\n"
            +"if(window.__gg)return;\n"
            +"const selected=new Map();\n"
            +"function findImage(t){return t&&t.closest?t.closest('img'):null;}\n"
            +"function url(im){\n"
            +" const candidates=[];\n"
            +" const add=u=>{if(typeof u!=='string'||!u.trim())return;try{const x=new URL(u,location.href);if(/^https?:$/.test(x.protocol)&&!candidates.includes(x.href))candidates.push(x.href);}catch(e){}};\n"
            +" let p=im;\n"
            +" for(let i=0;p&&i<4;i++,p=p.parentElement){\n"
            +"  if(p.getAttribute){['data-iurl','data-original','data-full','data-full-src','data-src','data-gif','data-url'].forEach(a=>add(p.getAttribute(a)));}\n"
            +"  if(p.tagName==='A'){\n"
            +"   const href=p.getAttribute('href')||'';\n"
            +"   try{const h=new URL(href,location.href);['imgurl','mediaurl','url'].forEach(k=>add(h.searchParams.get(k)));if(/\\.(gif|png|webp|jpe?g)(?:[?#]|$)/i.test(h.pathname))add(h.href);}catch(e){}\n"
            +"  }\n"
            +" }\n"
            +" const card=im.closest('a,figure,article,[data-id],[class*=item],[class*=card]')||im.parentElement;\n"
            +" if(card){const vids=card.querySelectorAll('video,video source,source[type*=video]');vids.forEach(v=>{add(v.getAttribute('data-src'));add(v.getAttribute('src'));add(v.currentSrc);});}\n"
            +" add(im.getAttribute('data-src'));add(im.currentSrc);add(im.src);\n"
            +" return candidates.find(x=>/\\.(gif|mp4|webm)(?:[?#]|$)/i.test(x))||candidates[0]||'';\n"
            +"}\n"
            +"function images(){return [...document.images].filter(e=>e.width>35&&e.height>35&&url(e));}\n"
            +"function paint(){images().forEach(e=>{e.style.outline=selected.has(url(e))?'4px solid #2463d3':'';e.style.outlineOffset=selected.has(url(e))?'-4px':'';});GifGrabberNative.selection(selected.size);}\n"
            +"function toggle(im){const k=url(im);if(!k)return;if(selected.has(k))selected.delete(k);else selected.set(k,k);paint();}\n"
            +"let timer=null,active=null,startX=0,startY=0,swiping=false,consumed=false,suppressUntil=0;\n"
            +"function stop(e){if(e.cancelable)e.preventDefault();e.stopImmediatePropagation();}\n"
            +"document.addEventListener('touchstart',e=>{\n"
            +" if(e.touches.length!==1)return;\n"
            +" active=findImage(e.target);swiping=false;consumed=false;\n"
            +" if(!active)return;\n"
            +" startX=e.touches[0].clientX;startY=e.touches[0].clientY;\n"
            +" clearTimeout(timer);\n"
            +" timer=setTimeout(()=>{if(active&&!swiping){toggle(active);consumed=true;suppressUntil=Date.now()+900;}},650);\n"
            +" // Keep image-touch sequences away from gallery/carousel swipe listeners.\n"
            +" e.stopImmediatePropagation();\n"
            +"}, {capture:true,passive:true});\n"
            +"document.addEventListener('touchmove',e=>{\n"
            +" if(!active||!e.touches.length)return;\n"
            +" const dx=e.touches[0].clientX-startX,dy=e.touches[0].clientY-startY;\n"
            +" if(Math.abs(dx)>12||Math.abs(dy)>12)clearTimeout(timer);\n"
            +" if((swiping||dx>12&&Math.abs(dx)>Math.abs(dy)*1.3)&&dx>0){swiping=true;stop(e);}\n"
            +"}, {capture:true,passive:false});\n"
            +"document.addEventListener('touchend',e=>{\n"
            +" clearTimeout(timer);if(!active)return;\n"
            +" const p=e.changedTouches[0];const dx=p?p.clientX-startX:0,dy=p?p.clientY-startY:0;\n"
            +" if(swiping||dx>35&&Math.abs(dx)>Math.abs(dy)*1.3){\n"
            +"  stop(e);consumed=true;suppressUntil=Date.now()+1200;\n"
            +"  if(dx>85&&Math.abs(dy)<85){const u=url(active);if(u)GifGrabberNative.download(JSON.stringify([u]));}\n"
            +" }\n"
            +" active=null;\n"
            +"},{capture:true,passive:false});\n"
            +"document.addEventListener('touchcancel',e=>{clearTimeout(timer);active=null;swiping=false;},{capture:true});\n"
            +"document.addEventListener('contextmenu',e=>{const im=findImage(e.target);if(im){stop(e);if(!consumed)toggle(im);consumed=true;suppressUntil=Date.now()+900;}},true);\n"
            +"document.addEventListener('click',e=>{const im=findImage(e.target);if(im&&(selected.size||consumed||Date.now()<suppressUntil)){stop(e);if(selected.size&&!consumed&&Date.now()>=suppressUntil)toggle(im);consumed=false;}},true);\n"
            +"window.__gg={all(){images().forEach(e=>selected.set(url(e),url(e)));paint();},download(){GifGrabberNative.download(JSON.stringify([...selected.values()]));selected.clear();paint();},clear(){selected.clear();paint();}};\n"
            +"})();"; }
    @Override protected void onDestroy(){pool.shutdownNow();if(web!=null)web.destroy();super.onDestroy();}
}
