package com.gifgrabber.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private LinearLayout selectionBar;
    private LinearLayout clipboardBar;
    private ClipboardManager clipboard;
    private TextView selectionCount;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final AtomicInteger filenameSequence = new AtomicInteger();
    private final String home = "https://www.google.com/search?tbm=isch&q=animated+gifs";
    private int count = 0;
    private int px(float dp) { return (int)(getResources().getDisplayMetrics().density*dp+0.5f); }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(px(radius));return d; }
    private TextView button(String label, Runnable action) {
        TextView b=new TextView(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setGravity(Gravity.CENTER);b.setPadding(px(12),px(12),px(12),px(12));b.setBackground(bg(0xff2463d3,12));b.setOnClickListener(v->action.run());return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);setContentView(root);
        // Android 15+ edge-to-edge: keep toolbar BELOW the system status bar.
        root.setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
            v.setPadding(0,bars.top,0,bars.bottom);
            return insets;
        });
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);nav.setPadding(px(5),px(5),px(5),px(5));nav.setBackgroundColor(0xfff3f5f8);root.addView(nav,new LinearLayout.LayoutParams(-1,px(55)));
        TextView back=new TextView(this);back.setText("‹");back.setTextSize(32);back.setGravity(Gravity.CENTER);nav.addView(back,new LinearLayout.LayoutParams(px(39),-1));back.setOnClickListener(v->{if(web.canGoBack())web.goBack();});
        address=new EditText(this);address.setSingleLine(true);address.setTextSize(14);address.setSelectAllOnFocus(true);address.setPadding(px(13),0,px(13),0);address.setBackground(bg(Color.WHITE,22));address.setImeOptions(2);nav.addView(address,new LinearLayout.LayoutParams(0,px(42),1));
        address.setOnFocusChangeListener((v,hasFocus)->{if(hasFocus){address.selectAll();}});
        address.setOnEditorActionListener((v,id,event)->{go(address.getText().toString());return true;});
        TextView go=new TextView(this);go.setText("➜");go.setTextSize(23);go.setGravity(Gravity.CENTER);nav.addView(go,new LinearLayout.LayoutParams(px(43),-1));go.setOnClickListener(v->go(address.getText().toString()));
        // Clipboard suggestion is shown only if clipboard contains something; contents are read on tap.
        clipboardBar=new LinearLayout(this);clipboardBar.setGravity(Gravity.CENTER_VERTICAL);
        clipboardBar.setPadding(px(12),px(6),px(12),px(6));clipboardBar.setBackgroundColor(0xffeaf2ff);
        TextView hint=new TextView(this);hint.setText("Copied a link?  Paste & Open");hint.setTextColor(0xff164b9b);hint.setTextSize(14);
        clipboardBar.addView(hint,new LinearLayout.LayoutParams(0,px(40),1));
        hint.setOnClickListener(v->pasteAndOpen());
        TextView paste=button("Paste & Open",()->pasteAndOpen());clipboardBar.addView(paste);
        TextView dismiss=new TextView(this);dismiss.setText("  ✕  ");dismiss.setTextSize(22);dismiss.setGravity(Gravity.CENTER);
        clipboardBar.addView(dismiss);dismiss.setOnClickListener(v->clipboardBar.setVisibility(View.GONE));
        clipboardBar.setVisibility(View.GONE);root.addView(clipboardBar,new LinearLayout.LayoutParams(-1,px(56)));
        web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setBuiltInZoomControls(true);web.getSettings().setDisplayZoomControls(false);web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new Bridge(),"GifGrabberNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){address.setText(url);resetSelection();web.evaluateJavascript(script(),null);}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !"http".equals(r.getUrl().getScheme())&&!"https".equals(r.getUrl().getScheme());}
        });
        selectionBar=new LinearLayout(this);selectionBar.setGravity(Gravity.CENTER_VERTICAL);selectionBar.setPadding(px(8),px(7),px(8),px(7));selectionBar.setBackgroundColor(0xffe9f0ff);selectionBar.setVisibility(View.GONE);root.addView(selectionBar,new LinearLayout.LayoutParams(-1,px(64)));
        selectionCount=new TextView(this);selectionCount.setTextColor(0xff1d376c);selectionCount.setTypeface(null,Typeface.BOLD);selectionCount.setTextSize(14);selectionBar.addView(selectionCount,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=button("Select All",()->web.evaluateJavascript("window.__gg&&__gg.all()",null));selectionBar.addView(all);
        TextView dl=button("Download",()->web.evaluateJavascript("window.__gg&&__gg.download()",null));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=px(6);selectionBar.addView(dl,p);
        TextView close=button("✕",()->web.evaluateJavascript("window.__gg&&__gg.clear()",null));p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=px(6);selectionBar.addView(close,p);
        web.loadUrl(home);
    }
    @Override protected void onResume(){super.onResume();if(clipboardBar!=null){
        boolean has=false;try{has=clipboard!=null&&clipboard.hasPrimaryClip();}catch(Exception ignored){}
        clipboardBar.setVisibility(has?View.VISIBLE:View.GONE);
    }}
    private void pasteAndOpen(){
        try{
            ClipData data=clipboard==null?null:clipboard.getPrimaryClip();
            if(data==null||data.getItemCount()==0)return;
            CharSequence cs=data.getItemAt(0).coerceToText(this);
            String value=cs==null?"":cs.toString().trim();
            if(value.matches("(?i)^https?://\\S+$")){
                address.setText(value);clipboardBar.setVisibility(View.GONE);go(value);
            }else{Toast.makeText(this,"Clipboard does not contain a web link",Toast.LENGTH_SHORT).show();}
        }catch(Exception e){Toast.makeText(this,"Cannot read clipboard",Toast.LENGTH_SHORT).show();}
    }
    private void go(String raw){String u=raw.trim();if(u.isEmpty())return;if(!u.matches("(?i)^https?://.*")){if(u.contains(".")&&!u.contains(" "))u="https://"+u;else u="https://www.google.com/search?q="+Uri.encode(u);}web.loadUrl(u);address.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);}
    private void resetSelection(){count=0;selectionBar.setVisibility(View.GONE);}
    @Override public void onBackPressed(){if(count>0){web.evaluateJavascript("window.__gg&&__gg.clear()",null);}else if(web.canGoBack())web.goBack();else super.onBackPressed();}
    private class Bridge {
        @JavascriptInterface public void selection(int n){runOnUiThread(()->{count=n;selectionCount.setText(n+" selected");selectionBar.setVisibility(n>0?View.VISIBLE:View.GONE);});}
        @JavascriptInterface public void download(String json){try{JSONArray a=new JSONArray(json);LinkedHashSet<String> urls=new LinkedHashSet<>();for(int i=0;i<a.length();i++){String u=a.optString(i,"");if(u.startsWith("https://")||u.startsWith("http://"))urls.add(u);}runOnUiThread(()->Toast.makeText(MainActivity.this,"Checking "+urls.size()+" GIF(s)",Toast.LENGTH_SHORT).show());for(String u:urls)pool.execute(()->saveGif(u));}catch(Exception ignored){}}
    }
    private void saveGif(String link){
        HttpURLConnection c=null;Uri pending=null;
        try{
            URL url=new URL(link);if(!url.getProtocol().equals("https")&&!url.getProtocol().equals("http"))return;
            c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Mozilla/5.0 GIFGrabber/2.0");
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            try(InputStream in=new BufferedInputStream(c.getInputStream())){
                byte[] header=new byte[6];int read=0;while(read<6){int n=in.read(header,read,6-read);if(n<0)break;read+=n;}
                String magic=new String(header,0,read,java.nio.charset.StandardCharsets.US_ASCII);
                if(!magic.equals("GIF87a")&&!magic.equals("GIF89a"))throw new IOException("Not an original GIF");
                String name="gif_grabber_"+System.currentTimeMillis()+"_"+filenameSequence.incrementAndGet()+".gif";
                OutputStream out;
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,name);values.put(MediaStore.Downloads.MIME_TYPE,"image/gif");values.put(MediaStore.Downloads.RELATIVE_PATH,"Download/GIFGrabber");values.put(MediaStore.Downloads.IS_PENDING,1);
                    pending=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(pending==null)throw new IOException("Cannot create download");out=getContentResolver().openOutputStream(pending);
                }else{
                    File dir=new File(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS),"GIFGrabber");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create folder");out=new FileOutputStream(new File(dir,name));
                }
                if(out==null)throw new IOException("Cannot open output");
                try(OutputStream dest=out){dest.write(header);byte[] buf=new byte[8192];int n;long total=6;while((n=in.read(buf))!=-1){total+=n;if(total>50L*1024*1024)throw new IOException("GIF larger than 50 MB");dest.write(buf,0,n);}}
                if(Build.VERSION.SDK_INT>=29){ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(pending,done,null,null);}
                runOnUiThread(()->Toast.makeText(this,"Saved "+name,Toast.LENGTH_SHORT).show());
            }
        }catch(Exception e){if(pending!=null&&Build.VERSION.SDK_INT>=29)getContentResolver().delete(pending,null,null);runOnUiThread(()->Toast.makeText(this,"Skipped: "+e.getMessage(),Toast.LENGTH_SHORT).show());}
        finally{if(c!=null)c.disconnect();}
    }
    private String script(){return "(function(){if(window.__gg)return;"+
      "const selected=new Map();const key=e=>e.currentSrc||e.src||'';"+
      "function images(){return [...document.images].filter(e=>e.width>35&&e.height>35&&/^https?:/.test(key(e)));}"+
      "function paint(){images().forEach(e=>{e.style.outline=selected.has(key(e))?'4px solid #2463d3':'';e.style.outlineOffset=selected.has(key(e))?'-4px':'';});GifGrabberNative.selection(selected.size);}"+
      "function toggle(e){const k=key(e);if(!k)return;if(selected.has(k))selected.delete(k);else selected.set(k,k);paint();}"+
      "function findImage(t){return t&&t.closest?t.closest('img'):null;}"+
      "let timer=null,startX=0,startY=0,active=null,consumed=false;"+
      "document.addEventListener('touchstart',ev=>{if(ev.touches.length!==1)return;active=findImage(ev.target);consumed=false;if(!active)return;startX=ev.touches[0].clientX;startY=ev.touches[0].clientY;clearTimeout(timer);timer=setTimeout(()=>{if(active){toggle(active);consumed=true;}},650);},{passive:true,capture:true});"+
      "document.addEventListener('touchmove',ev=>{if(!active||!ev.touches.length)return;const dx=ev.touches[0].clientX-startX,dy=ev.touches[0].clientY-startY;if(Math.abs(dx)>14||Math.abs(dy)>14)clearTimeout(timer);if(dx>18&&Math.abs(dx)>Math.abs(dy)*1.5&&ev.cancelable){ev.preventDefault();consumed=true;}},{passive:false,capture:true});"+
      "document.addEventListener('touchend',ev=>{clearTimeout(timer);if(!active)return;const p=ev.changedTouches[0];if(p&&p.clientX-startX>95&&Math.abs(p.clientY-startY)<65){GifGrabberNative.download(JSON.stringify([key(active)]));consumed=true;}active=null;},{passive:true,capture:true});"+
      "document.addEventListener('contextmenu',ev=>{const im=findImage(ev.target);if(im){ev.preventDefault();if(!consumed)toggle(im);consumed=true;}},true);"+
       "document.addEventListener('click',ev=>{const im=findImage(ev.target);if(im&&(selected.size||consumed)){ev.preventDefault();ev.stopPropagation();if(selected.size&&!consumed)toggle(im);consumed=false;}},true);"+
      "window.__gg={all(){images().forEach(e=>selected.set(key(e),key(e)));paint();},download(){GifGrabberNative.download(JSON.stringify([...selected.values()]));selected.clear();paint();},clear(){selected.clear();paint();}};"+
      "})();";}
    @Override protected void onDestroy(){pool.shutdownNow();if(web!=null)web.destroy();super.onDestroy();}
}
