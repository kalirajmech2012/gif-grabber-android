package com.gifgrabber.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private LinearLayout selectionBar;
    private LinearLayout clipboardBar;
    private ClipboardManager clipboard;
    private TextView selectionCount;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final AtomicInteger filenameSequence = new AtomicInteger();
    private final String home = "https://www.google.com/search?tbm=isch&q=animated+gifs";
    private int count = 0;
    private int px(float dp) { return (int)(getResources().getDisplayMetrics().density*dp+0.5f); }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(px(radius));return d; }
    private TextView button(String label, Runnable action) {
        TextView b=new TextView(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setGravity(Gravity.CENTER);b.setPadding(px(12),px(12),px(12),px(12));b.setBackground(bg(0xff2463d3,12));b.setOnClickListener(v->action.run());return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);setContentView(root);
        // Android 15+ edge-to-edge: keep toolbar BELOW the system status bar.
        root.setOnApplyWindowInsetsListener((v,insets)->{
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
            v.setPadding(0,bars.top,0,bars.bottom);
            return insets;
        });
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);nav.setPadding(px(5),px(5),px(5),px(5));nav.setBackgroundColor(0xfff3f5f8);root.addView(nav,new LinearLayout.LayoutParams(-1,px(55)));
        TextView back=new TextView(this);back.setText("‹");back.setTextSize(32);back.setGravity(Gravity.CENTER);nav.addView(back,new LinearLayout.LayoutParams(px(39),-1));back.setOnClickListener(v->{if(web.canGoBack())web.goBack();});
        address=new EditText(this);address.setSingleLine(true);address.setTextSize(14);address.setSelectAllOnFocus(true);address.setPadding(px(13),0,px(13),0);address.setBackground(bg(Color.WHITE,22));address.setImeOptions(2);nav.addView(address,new LinearLayout.LayoutParams(0,px(42),1));
        address.setOnFocusChangeListener((v,hasFocus)->{if(hasFocus){address.selectAll();}});
        address.setOnEditorActionListener((v,id,event)->{go(address.getText().toString());return true;});
        TextView go=new TextView(this);go.setText("➜");go.setTextSize(23);go.setGravity(Gravity.CENTER);nav.addView(go,new LinearLayout.LayoutParams(px(43),-1));go.setOnClickListener(v->go(address.getText().toString()));
        // Clipboard suggestion is shown only if clipboard contains something; contents are read on tap.
        clipboardBar=new LinearLayout(this);clipboardBar.setGravity(Gravity.CENTER_VERTICAL);
        clipboardBar.setPadding(px(12),px(6),px(12),px(6));clipboardBar.setBackgroundColor(0xffeaf2ff);
        TextView hint=new TextView(this);hint.setText("Copied a link?  Paste & Open");hint.setTextColor(0xff164b9b);hint.setTextSize(14);
        clipboardBar.addView(hint,new LinearLayout.LayoutParams(0,px(40),1));
        hint.setOnClickListener(v->pasteAndOpen());
        TextView paste=button("Paste & Open",()->pasteAndOpen());clipboardBar.addView(paste);
        TextView dismiss=new TextView(this);dismiss.setText("  ✕  ");dismiss.setTextSize(22);dismiss.setGravity(Gravity.CENTER);
        clipboardBar.addView(dismiss);dismiss.setOnClickListener(v->clipboardBar.setVisibility(View.GONE));
        clipboardBar.setVisibility(View.GONE);root.addView(clipboardBar,new LinearLayout.LayoutParams(-1,px(56)));
        web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setBuiltInZoomControls(true);web.getSettings().setDisplayZoomControls(false);web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new Bridge(),"GifGrabberNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){address.setText(url);resetSelection();web.evaluateJavascript(script(),null);}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !"http".equals(r.getUrl().getScheme())&&!"https".equals(r.getUrl().getScheme());}
        });
        selectionBar=new LinearLayout(this);selectionBar.setGravity(Gravity.CENTER_VERTICAL);selectionBar.setPadding(px(8),px(7),px(8),px(7));selectionBar.setBackgroundColor(0xffe9f0ff);selectionBar.setVisibility(View.GONE);root.addView(selectionBar,new LinearLayout.LayoutParams(-1,px(64)));
        selectionCount=new TextView(this);selectionCount.setTextColor(0xff1d376c);selectionCount.setTypeface(null,Typeface.BOLD);selectionCount.setTextSize(14);selectionBar.addView(selectionCount,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=button("Select All",()->web.evaluateJavascript("window.__gg&&__gg.all()",null));selectionBar.addView(all);
        TextView dl=button("Download",()->web.evaluateJavascript("window.__gg&&__gg.download()",null));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=px(6);selectionBar.addView(dl,p);
        TextView close=button("✕",()->web.evaluateJavascript("window.__gg&&__gg.clear()",null));p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=px(6);selectionBar.addView(close,p);
        web.loadUrl(home);
    }
    @Override protected void onResume(){super.onResume();if(clipboardBar!=null){
        boolean has=false;try{has=clipboard!=null&&clipboard.hasPrimaryClip();}catch(Exception ignored){}
        clipboardBar.setVisibility(has?View.VISIBLE:View.GONE);
    }}
    private void pasteAndOpen(){
        try{
            ClipData data=clipboard==null?null:clipboard.getPrimaryClip();
            if(data==null||data.getItemCount()==0)return;
            CharSequence cs=data.getItemAt(0).coerceToText(this);
            String value=cs==null?"":cs.toString().trim();
            if(value.matches("(?i)^https?://\\S+$")){
                address.setText(value);clipboardBar.setVisibility(View.GONE);go(value);
            }else{Toast.makeText(this,"Clipboard does not contain a web link",Toast.LENGTH_SHORT).show();}
        }catch(Exception e){Toast.makeText(this,"Cannot read clipboard",Toast.LENGTH_SHORT).show();}
    }
    private void go(String raw){String u=raw.trim();if(u.isEmpty())return;if(!u.matches("(?i)^https?://.*")){if(u.contains(".")&&!u.contains(" "))u="https://"+u;else u="https://www.google.com/search?q="+Uri.encode(u);}web.loadUrl(u);address.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);}
    private void resetSelection(){count=0;selectionBar.setVisibility(View.GONE);}
    @Override public void onBackPressed(){if(count>0){web.evaluateJavascript("window.__gg&&__gg.clear()",null);}else if(web.canGoBack())web.goBack();else super.onBackPressed();}
    private class Bridge {
        @JavascriptInterface public void selection(int n){runOnUiThread(()->{count=n;selectionCount.setText(n+" selected");selectionBar.setVisibility(n>0?View.VISIBLE:View.GONE);});}
        @JavascriptInterface public void download(String json){try{JSONArray a=new JSONArray(json);LinkedHashSet<String> urls=new LinkedHashSet<>();for(int i=0;i<a.length();i++){String u=a.optString(i,"");if(u.startsWith("https://")||u.startsWith("http://"))urls.add(u);}runOnUiThread(()->{
            if(urls.isEmpty())return;
            // WebView and CookieManager must be accessed on the UI thread.
            final String userAgent=web.getSettings().getUserAgentString();
            final String referer=web.getUrl();
            Toast.makeText(MainActivity.this,"Checking "+urls.size()+" image(s)",Toast.LENGTH_SHORT).show();
            for(String u:urls){
                String cookies=android.webkit.CookieManager.getInstance().getCookie(u);
                pool.execute(()->saveGif(u,userAgent,referer,cookies));
            }
        });}catch(Exception ignored){}}
    }
    private void saveGif(String link,String userAgent,String referer,String cookies){
        HttpURLConnection c=null;Uri pending=null;
        try{
            URL url=new URL(link);
            if(!url.getProtocol().equals("https")&&!url.getProtocol().equals("http"))return;
            c=(HttpURLConnection)url.openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent",userAgent);
            c.setRequestProperty("Accept","image/gif,image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
            if(referer!=null&&referer.startsWith("http"))c.setRequestProperty("Referer",referer);
            if(cookies!=null)c.setRequestProperty("Cookie",cookies);
            if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
            try(InputStream in=new BufferedInputStream(c.getInputStream())){
                byte[] head=new byte[16];int read=0;
                while(read<head.length){int n=in.read(head,read,head.length-read);if(n<0)break;read+=n;}
                String ascii=new String(head,0,read,java.nio.charset.StandardCharsets.US_ASCII);
                String mime="",ext="";
                if(ascii.startsWith("GIF87a")||ascii.startsWith("GIF89a")){mime="image/gif";ext="gif";}
                else if(read>=8&&(head[0]&255)==137&&ascii.substring(1,4).equals("PNG")){mime="image/png";ext="png";}
                else if(read>=3&&(head[0]&255)==255&&(head[1]&255)==216&&(head[2]&255)==255){mime="image/jpeg";ext="jpg";}
                else if(ascii.startsWith("RIFF")&&ascii.length()>=12&&ascii.substring(8,12).equals("WEBP")){mime="image/webp";ext="webp";}
                else if(read>=12&&ascii.substring(4,8).equals("ftyp")&&ascii.substring(8,12).contains("avif")){mime="image/avif";ext="avif";}
                else throw new IOException("URL did not return a supported image");
                String name="gif_grabber_"+System.currentTimeMillis()+"_"+filenameSequence.incrementAndGet()+"."+ext;
                OutputStream stream;
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    values.put(MediaStore.Downloads.MIME_TYPE,mime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH,"Download/GIFGrabber");values.put(MediaStore.Downloads.IS_PENDING,1);
                    pending=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(pending==null)throw new IOException("Cannot create download");
                    stream=getContentResolver().openOutputStream(pending);
                }else{
                    File dir=new File(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS),"GIFGrabber");
                    if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create folder");
                    stream=new FileOutputStream(new File(dir,name));
                }
                if(stream==null)throw new IOException("Cannot open output");
                try(OutputStream dest=stream){dest.write(head,0,read);byte[] buf=new byte[8192];int n;long total=read;
                    while((n=in.read(buf))!=-1){total+=n;if(total>50L*1024*1024)throw new IOException("Image larger than 50 MB");dest.write(buf,0,n);}}
                if(Build.VERSION.SDK_INT>=29){ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(pending,done,null,null);}
                final String label=ext.equals("gif")?"GIF saved: ":"Image saved ("+ext+", not GIF): ";
                runOnUiThread(()->Toast.makeText(this,label+name,Toast.LENGTH_SHORT).show());
            }
        }catch(Exception e){if(pending!=null&&Build.VERSION.SDK_INT>=29)getContentResolver().delete(pending,null,null);
            runOnUiThread(()->Toast.makeText(this,"Download failed: "+e.getMessage(),Toast.LENGTH_SHORT).show());}
        finally{if(c!=null)c.disconnect();}
    }
    private String script(){return "(function(){\n"
            +"if(window.__gg)return;\n"
            +"const selected=new Map();\n"
            +"function findImage(t){return t&&t.closest?t.closest('img'):null;}\n"
            +"function url(im){\n"
            +" const candidates=[];\n"
            +" const add=u=>{if(typeof u!=='string'||!u.trim())return;try{const x=new URL(u,location.href);if(/^https?:$/.test(x.protocol)&&!candidates.includes(x.href))candidates.push(x.href);}catch(e){}};\n"
            +" let p=im;\n"
            +" for(let i=0;p&&i<4;i++,p=p.parentElement){\n"
            +"  if(p.getAttribute){['data-iurl','data-original','data-full','data-full-src','data-src','data-gif','data-url'].forEach(a=>add(p.getAttribute(a)));}\n"
            +"  if(p.tagName==='A'){\n"
            +"   const href=p.getAttribute('href')||'';\n"
            +"   try{const h=new URL(href,location.href);['imgurl','mediaurl','url'].forEach(k=>add(h.searchParams.get(k)));if(/\\.(gif|png|webp|jpe?g)(?:[?#]|$)/i.test(h.pathname))add(h.href);}catch(e){}\n"
            +"  }\n"
            +" }\n"
            +" add(im.getAttribute('data-src'));add(im.currentSrc);add(im.src);\n"
            +" return candidates.find(x=>/\\.gif(?:[?#]|$)/i.test(x))||candidates[0]||'';\n"
            +"}\n"
            +"function images(){return [...document.images].filter(e=>e.width>35&&e.height>35&&url(e));}\n"
            +"function paint(){images().forEach(e=>{e.style.outline=selected.has(url(e))?'4px solid #2463d3':'';e.style.outlineOffset=selected.has(url(e))?'-4px':'';});GifGrabberNative.selection(selected.size);}\n"
            +"function toggle(im){const k=url(im);if(!k)return;if(selected.has(k))selected.delete(k);else selected.set(k,k);paint();}\n"
            +"let timer=null,active=null,startX=0,startY=0,swiping=false,consumed=false,suppressUntil=0;\n"
            +"function stop(e){if(e.cancelable)e.preventDefault();e.stopImmediatePropagation();}\n"
            +"document.addEventListener('touchstart',e=>{\n"
            +" if(e.touches.length!==1)return;\n"
            +" active=findImage(e.target);swiping=false;consumed=false;\n"
            +" if(!active)return;\n"
            +" startX=e.touches[0].clientX;startY=e.touches[0].clientY;\n"
            +" clearTimeout(timer);\n"
            +" timer=setTimeout(()=>{if(active&&!swiping){toggle(active);consumed=true;suppressUntil=Date.now()+900;}},650);\n"
            +" // Keep image-touch sequences away from gallery/carousel swipe listeners.\n"
            +" e.stopImmediatePropagation();\n"
            +"}, {capture:true,passive:true});\n"
            +"document.addEventListener('touchmove',e=>{\n"
            +" if(!active||!e.touches.length)return;\n"
            +" const dx=e.touches[0].clientX-startX,dy=e.touches[0].clientY-startY;\n"
            +" if(Math.abs(dx)>12||Math.abs(dy)>12)clearTimeout(timer);\n"
            +" if((swiping||dx>12&&Math.abs(dx)>Math.abs(dy)*1.3)&&dx>0){swiping=true;stop(e);}\n"
            +"}, {capture:true,passive:false});\n"
            +"document.addEventListener('touchend',e=>{\n"
            +" clearTimeout(timer);if(!active)return;\n"
            +" const p=e.changedTouches[0];const dx=p?p.clientX-startX:0,dy=p?p.clientY-startY:0;\n"
            +" if(swiping||dx>35&&Math.abs(dx)>Math.abs(dy)*1.3){\n"
            +"  stop(e);consumed=true;suppressUntil=Date.now()+1200;\n"
            +"  if(dx>85&&Math.abs(dy)<85){const u=url(active);if(u)GifGrabberNative.download(JSON.stringify([u]));}\n"
            +" }\n"
            +" active=null;\n"
            +"},{capture:true,passive:false});\n"
            +"document.addEventListener('touchcancel',e=>{clearTimeout(timer);active=null;swiping=false;},{capture:true});\n"
            +"document.addEventListener('contextmenu',e=>{const im=findImage(e.target);if(im){stop(e);if(!consumed)toggle(im);consumed=true;suppressUntil=Date.now()+900;}},true);\n"
            +"document.addEventListener('click',e=>{const im=findImage(e.target);if(im&&(selected.size||consumed||Date.now()<suppressUntil)){stop(e);if(selected.size&&!consumed&&Date.now()>=suppressUntil)toggle(im);consumed=false;}},true);\n"
            +"window.__gg={all(){images().forEach(e=>selected.set(url(e),url(e)));paint();},download(){GifGrabberNative.download(JSON.stringify([...selected.values()]));selected.clear();paint();},clear(){selected.clear();paint();}};\n"
            +"})();"; }
    @Override protected void onDestroy(){pool.shutdownNow();if(web!=null)web.destroy();super.onDestroy();}
}
