package com.gifgrabber.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.*;
import android.text.InputType;
import org.json.JSONArray;
import java.util.LinkedHashSet;
import java.util.ArrayList;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView browser;
    private EditText address;
    private TextView status;
    private LinearLayout results;
    private final LinkedHashSet<String> found = new LinkedHashSet<>();
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();
    private static final String SCAN_JS = "(function(){let s=new Set();function add(u){if(!u)return;try{let x=new URL(u,location.href).href;if(/^https?:/.test(x)&&(/\\.gif(?:[?#]|$)/i.test(x)||/\\.gif\\?/i.test(x)))s.add(x)}catch(e){}}document.querySelectorAll('img,source,a').forEach(e=>{add(e.src);add(e.href);add(e.currentSrc);let z=e.getAttribute('srcset');if(z)z.split(',').forEach(p=>add(p.trim().split(/\\s+/)[0]));});performance.getEntriesByType('resource').forEach(e=>add(e.name));return JSON.stringify([...s]);})()";
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private Button button(String title, LinearLayout parent, View.OnClickListener listener){Button b=new Button(this);b.setText(title);parent.addView(b);b.setOnClickListener(listener);return b;}
    @Override public void onCreate(Bundle state){super.onCreate(state);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(8),dp(8),dp(8),dp(8));root.setBackgroundColor(Color.WHITE);setContentView(root);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);root.addView(bar);
        address=new EditText(this);address.setSingleLine(true);address.setHint("https://example.com");address.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);bar.addView(address,new LinearLayout.LayoutParams(0,dp(55),1));
        button("GO",bar,v->navigate());
        browser=new WebView(this);browser.getSettings().setJavaScriptEnabled(true);browser.getSettings().setDomStorageEnabled(true);browser.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);browser.setWebChromeClient(new WebChromeClient());browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){address.setText(url);status.setText("Page loaded. Scroll to load more, then Scan.");}});root.addView(browser,new LinearLayout.LayoutParams(-1,0,3));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);root.addView(actions);
        button("Scan GIFs",actions,v->scan());
        button("Download selected",actions,v->download());
        status=new TextView(this);status.setText("Enter a URL and tap GO.");status.setTextColor(Color.DKGRAY);status.setPadding(dp(6),dp(6),dp(6),dp(6));root.addView(status);
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,2));results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);scroll.addView(results);
    }
    private void navigate(){String url=address.getText().toString().trim();if(!url.startsWith("https://")&&!url.startsWith("http://"))url="https://"+url;browser.loadUrl(url);}
    private void scan(){browser.evaluateJavascript(SCAN_JS,value->{try{
        String json=new JSONArray("["+value+"]").getString(0);
        JSONArray arr=new JSONArray(json);int before=found.size();
        for(int i=0;i<arr.length();i++){String u=arr.getString(i);if(found.add(u))selected.add(u);}
        render();status.setText("Found "+found.size()+" GIF URLs ("+(found.size()-before)+" new). Scroll and scan again for more.");
    }catch(Exception e){status.setText("Scan error: "+e.getMessage());}});}
    private void render(){results.removeAllViews();for(String url:found){
        CheckBox cb=new CheckBox(this);cb.setText(url);cb.setTextSize(12);cb.setMaxLines(2);cb.setChecked(selected.contains(url));cb.setOnCheckedChangeListener((v,checked)->{if(checked)selected.add(url);else selected.remove(url);});results.addView(cb);
    }}
    private void download(){int count=0;DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
        String cookie=CookieManager.getInstance().getCookie(browser.getUrl()==null?"":browser.getUrl());
        for(String url:new ArrayList<>(selected)){try{
            Uri uri=Uri.parse(url);if(!"https".equalsIgnoreCase(uri.getScheme())&&!"http".equalsIgnoreCase(uri.getScheme()))continue;
            DownloadManager.Request req=new DownloadManager.Request(uri);req.setTitle("GIF Grabber");req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.addRequestHeader("User-Agent",browser.getSettings().getUserAgentString());if(cookie!=null)req.addRequestHeader("Cookie",cookie);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"GifGrabber/gif_"+System.currentTimeMillis()+"_"+count+".gif");
            dm.enqueue(req);count++;
        }catch(Exception ignored){}}
        status.setText("Queued "+count+" GIF downloads. Check Android Downloads for results.");
    }
    @Override public void onBackPressed(){if(browser.canGoBack())browser.goBack();else super.onBackPressed();}
}
