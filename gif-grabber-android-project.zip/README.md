# GIF Grabber V2

Full-screen Android WebView browser with an address bar, GIF long-press multi-selection, Select All, Download Selected, and swipe-right single GIF download. Only actual GIF87a/GIF89a files are saved. Dynamic Google image thumbnails may be JPEG/WEBP; those are skipped. Some websites may prevent original GIF retrieval or inject images in cross-origin frames. Select All covers images currently present in the page DOM, including those loaded by scrolling, not an entire search result catalog.

For Android 10+, GIFs go to Downloads/GIFGrabber. Android 8-9 uses app-specific external Downloads/GIFGrabber without storage permission.

To build: `gradle --no-daemon assembleDebug` using JDK 17, Gradle 8.9 and Android SDK 35.
