# GIF Grabber V5

Browser with top address bar, clipboard Paste & Open, image right-swipe, long-press multiple selection, Select All and Download.

- Original GIF is downloaded without conversion.
- Animated WebP is decoded via Android ImageDecoder/AnimatedImageDrawable and captured as GIF (Android 9+).
- MP4/WebM is decoded via MediaMetadataRetriever and encoded as GIF.
- Conversions are local, limited to first 6 seconds, about 8 fps, max 480px side, no sound.
- Static thumbnails are rejected rather than falsely saved as animated GIF.
- Some websites do not expose original media URLs in the webpage DOM. Such media cannot be automatically converted without a discoverable original URL.
- DRM/protected media unsupported. Animated WebP capture is device-dependent.

Build with existing GitHub Actions workflow using `gif-grabber-android-project.zip` as uploaded ZIP name.
GIF encoder tested with two frames. Full Android build and phone behavior not verified.
\nV5 Tabs: top tab-count button, new tab, switch tabs, close tabs, separate WebView and page history per tab.\n