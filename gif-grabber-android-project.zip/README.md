# GIF Grabber Android

Native Android WebView app for detecting and bulk-downloading direct GIF URLs.

## Usage
Enter a public webpage URL, tap GO, scroll to load content, and tap Scan GIFs. Select detected links and tap Download selected. Files are queued to Android Downloads/GifGrabber.

## Build
GitHub Actions > Build Android APK > Run workflow. After success, download the gif-grabber-debug-apk artifact ZIP and extract app-debug.apk.

## Limitations
Detects direct .gif URLs in page elements and performance entries, not GIF-like MP4/WebM, CSS backgrounds, protected content, inaccessible frames or blob resources. Sites may block WebView or downloading. Download only content you have permission to save. This is an unsigned-for-distribution debug build, intended for testing.
